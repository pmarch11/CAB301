﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;


namespace CAB301_assignment
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.ReadKey();
        }

        static void FunctionalCorrectnessTest()
        {
            Console.WriteLine("Functional testing\n");
            int[] sortedAsc = new int[] {2, 4, 6, 8, 10, 12, 14, 16, 18, 20 };
            int[] sortedDes = new int[] { 20, 18, 16, 14, 12, 10, 8, 6, 4, 2 };
            int[] almostSorted = new int[] { 2, 6, 4, 8, 10, 14, 12, 16, 18, 20 };
            int[] fewUnique = new int[] {4, 4, 4, 4, 4, 2, 3, 6, 6, 6 };
            int[] oddLength = new int[] {4, 5, 7, 10, 13, 15, 16, 16, 16 };

            int[][] tests = new int[][] { sortedAsc, sortedDes, almostSorted, fewUnique, oddLength };

            foreach(int [] test in tests)
            {
                Console.WriteLine(BruteForceMedian(test) + "\n");
            }
        }

        static int[] GenerateRandomArray(int arraySize)
        {
            Random rng = new Random(Environment.TickCount);
            int[] returnList = new int[arraySize];
            for(int i = 0;i < arraySize; i++)
            {
                returnList[i] = rng.Next(1, Int32.MaxValue);
            }
            return returnList;
        }

        static int[] ShuffleArray(int[] array)
        {
            Random rng = new Random(Environment.TickCount);

            for(int i=0;i < array.Length - 1; i++)
            {
                int j = rng.Next(i, array.Length);
                int temp = array[i];
                array[i] = array[j];
                array[j] = temp;
            }
            return array;
        }



        static int BruteForceMedian(int[] A)
        {
            //Stopwatch sw = new Stopwatch();
            //sw.Start();
            //int counter = 0; 
            int k = (int)Math.Ceiling(A.Length/2.0);
            for(int i = 0; i < A.Length - 1; i++)
            {
                int numSmaller = 0;
                int numEqual = 0;
                for(int j = 0; j < A.Length - 1 /*&& counter++ >= 0*/; j++)
                {
                    if(A[j] < A[i])
                    {
                        numSmaller++;
                    }
                    else
                    {
                        if(A[j] == A[i])
                        {
                            numEqual++;
                        }
                    }
                }
                if(numSmaller < k && k <= (numSmaller + numEqual)){
                    //sw.Stop();
                   // Console.WriteLine("Basic operations: {0}\nElapsed time (ms): {1}", counter, sw.ElapsedMilliseconds);
                    return A[i];
                }
            }
            return -1;
        }
    }
}

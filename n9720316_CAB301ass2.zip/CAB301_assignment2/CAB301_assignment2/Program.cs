﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;

namespace CAB301_assignment2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.ReadKey();
        }

        static void FunctionalCorrectnessTest()
        {
            Console.WriteLine("Functional testing\n");
            int[] sortedAsc = new int[] { 2, 4, 6, 8, 10, 12, 14, 16, 18, 20 };
            int[] sortedDes = new int[] { 20, 18, 16, 14, 12, 10, 8, 6, 4, 2 };
            int[] negativeNums = new int[] { -2, -4, -8, -10, -14, -12, -16, -18 };
            int[] allSame = new int[] { 4, 4, 4, 4, 4, 4, 4};
            int[] unsorted = new int[] { 4, -5, 2, 10, -15, 1, 20, -10 };

            int[][] tests = new int[][] { sortedAsc, sortedDes, negativeNums, allSame, unsorted };

            Console.WriteLine("MinDistance testing\n");
            foreach (int[] test in tests)
            {
                Console.WriteLine(MinDistance(test) + "\n");
            }
            Console.WriteLine("MinDistance2 testing\n");
            foreach (int[] test in tests)
            {
                Console.WriteLine(MinDistance2(test) + "\n");
            }
        }

        static int[] GenerateRandomArray(int arraySize)
        {
            Random rng = new Random(Environment.TickCount);
            int[] returnList = new int[arraySize];
            for (int i = 0; i < arraySize; i++)
            {
                returnList[i] = rng.Next(int.MinValue, int.MaxValue);
            }
            return returnList;
        }

        static int[] ShuffleArray(int[] array)
        {
            Random rng = new Random(Environment.TickCount);

            for (int i = 0; i < array.Length - 1; i++)
            {
                int j = rng.Next(i, array.Length);
                int temp = array[i];
                array[i] = array[j];
                array[j] = temp;
            }
            return array;
        }

        static int MinDistance(int[] A)
        {
            //Stopwatch sw = new Stopwatch();
            //sw.Start();
            int dmin = int.MaxValue;
            //int basicOpCounter = 0;
            for (int i = 0; i < A.Length - 1; i++)
            {
                for(int j = 0;j < A.Length - 1; j++)
                {
                    if(i !=j && /*++basicOpCounter > 0 &&*/ Math.Abs(A[i] - A[j]) < dmin)
                    {
                        dmin = Math.Abs(A[i] - A[j]);
                    }
                }
            }
            //sw.Stop();
            return dmin;
        }


        static int MinDistance2(int[] A)
        {
            //Stopwatch sw = new Stopwatch();
            //sw.Start();
            int dmin = int.MaxValue;
            //int basicOpCounter = 0;
            for(int i = 0;i < A.Length - 2; i++)
            {
                for(int j = i+1;j < A.Length - 1; j++)
                {
                    //++basicOpCounter;
                    int temp = Math.Abs(A[i] - A[j]);
                    if (temp < dmin)
                    {
                        dmin = temp;
                    }
                }
            }
            //sw.Stop();
            return dmin;
        }
    }
}
